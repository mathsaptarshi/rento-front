const ApiUrls = {
    hostURL: 'http://localhost:/',
    getJson: 'ptapiqa/api/MarriageBureaus'    
};
export default ApiUrls;
