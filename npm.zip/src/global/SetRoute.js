export default class SetRoute {
  // static  setRoute(props) {
  //   if(sessionStorage.getItem('isLogin')==='false' ||  sessionStorage.getItem('isLogin')===null){
  //   props.history.push("/")
  //   }
  // }
  static  alerMe(message) {
    alert(message)
  }
}
