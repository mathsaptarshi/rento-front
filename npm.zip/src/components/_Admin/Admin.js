import React, { Component } from 'react'

export default class Admin extends Component {
    render() {
        return (
            <div>
                Admin Section developed here
            </div>
        )
    }
}
